export var config = {
    apiKey: "AIzaSyA6pwcLnG-xuDcShFjnGlr_WsPV0ey_pW0",
    authDomain: "dynamicsapp-c47ec.firebaseapp.com",
    databaseURL: "https://dynamicsapp-c47ec.firebaseio.com",
    projectId: "dynamicsapp-c47ec",
    storageBucket: "dynamicsapp-c47ec.appspot.com",
    messagingSenderId: "965623335867"
};
