export interface usercreds {
    email: string;
    password: string;
}
