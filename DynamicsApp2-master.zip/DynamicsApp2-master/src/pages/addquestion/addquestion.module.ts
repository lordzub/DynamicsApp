import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddquestionPage } from './addquestion';

@NgModule({
  declarations: [
    AddquestionPage,
  ],
  imports: [
    IonicPageModule.forChild(AddquestionPage),
  ],
})
export class AddquestionPageModule {}
